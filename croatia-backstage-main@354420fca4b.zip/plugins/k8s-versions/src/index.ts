export { k8SVersionsPlugin, K8SVersionsPage } from './plugin';

package com.croatia.pipelines.helpers

enum VersionIncrement {
  Major,
  Minor,
  Patch,
  None
}

package com.croatia.tactical.pipelines.helpers

enum VersionIncrement {
  Major,
  Minor,
  Patch,
  None
}
